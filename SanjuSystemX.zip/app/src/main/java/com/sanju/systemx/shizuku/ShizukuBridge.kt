package com.sanju.systemx.shizuku

import android.content.Context

/** Extension point for future privileged operations. Nothing privileged is executed in this build. */
interface PrivilegedOps {
    fun isAvailable(): Boolean
    fun describe(): String
}

object NoPrivilegedOps : PrivilegedOps {
    override fun isAvailable() = false
    override fun describe() = "Advanced system operations unavailable."
}

object ShizukuBridge {
    private const val PKG = "moe.shizuku.privileged.api"

    @Suppress("DEPRECATION")
    fun isInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0); true
    } catch (e: Exception) { false }

    fun statusText(ctx: Context): String {
        val first = if (isInstalled(ctx)) "Shizuku app detected, but this build has no Shizuku API integration."
        else "Shizuku is not installed."
        return "$first\nShizuku Status: Not Connected\n${NoPrivilegedOps.describe()}"
    }
}
